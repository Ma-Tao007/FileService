var baseip = "192.168.1.83";
// //格式化日期
// function getLocalTime (shijianchuo) {
//     //shijianchuo是整数，否则要parseInt转换
//     var time = new Date(shijianchuo);
//     var y = time.getFullYear();
//     var m = time.getMonth()+1;
//     var d = time.getDate();
//     var h = time.getHours();
//     var mm = time.getMinutes();
//     var s = time.getSeconds();
//     return y+'-'+add0(m)+'-'+add0(d)+' '+add0(h)+':'+add0(mm)+':'+add0(s);
// }
// function add0(m){
//     return m<10?'0'+m:m
// }
//登录密码加盐 salt
var g_passsword_salt="1a2b3c4d"
