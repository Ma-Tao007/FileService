(function ($) {
    var intervalMap = {};
    var timeDifference = null;
    $.fn.downCount = function (options, callback) {
        var settings = $.extend({nowdate: null, offset: null, key: null}, options);
        if (!settings.nowdate) {
            $.error('Date is not defined.');
        }
        if (!Date.parse(settings.nowdate)) {
            $.error('Incorrect date format, it should look like this, 12/24/2012 12:00:00.');
        }
        //定时器key（使用标的id作为唯一标识）
        var key = settings.key;
        //页面加载的时候传递过来的服务器时间
        var nowdate = settings.nowdate;
        //竞价开始时间
        var starttime = settings.starttime;
        //计算传递进来的服务器时间和当前本地时间之差
        timeDifference = new Date(nowdate).getTime() - new Date().getTime();
        var container = this;
        var currentDate = function () {
            var date = new Date();
            date.setTime(date.getTime() + timeDifference)
            var utc = date.getTime() + (date.getTimezoneOffset() * 60000);
            var new_date = new Date(utc + (3600000 * settings.offset))
            return new_date;
        };
        console.log("setting",settings);
        function countdown() {
            //先根据开始时间进行倒计时，显示：距离开市时间还有xxxx
            var target_date = new Date(settings.starttime), current_date = currentDate();
            var difference = target_date - current_date;

            if (difference > 0) {
                //竞价开始时间大于当前时间，竞价未开始，显示当前距离开始时间的倒计时
                var _second = 1000, _minute = _second * 60, _hour = _minute * 60, _day = _hour * 24;
                var days = Math.floor(difference / _day), hours = Math.floor((difference % _day) / _hour),
                    minutes = Math.floor((difference % _hour) / _minute),
                    seconds = Math.floor((difference % _minute) / _second);
                days = (String(days).length >= 2) ? days : '0' + days;
                hours = (String(hours).length >= 2) ? hours : '0' + hours;
                minutes = (String(minutes).length >= 2) ? minutes : '0' + minutes;
                seconds = (String(seconds).length >= 2) ? seconds : '0' + seconds;
                container.html(`<span>距离开市还有${days}天${hours}时${minutes}分${seconds}秒</span>`)
            } else {
                //竞价开始时间小于当前时间，竞价已经开始，显示当前距离竞价结束的倒计时
                target_date = new Date(settings.endtime)
                current_date = currentDate();
                difference = target_date - current_date;
                //结束时间小于当前时间，也就是倒计时结束了
                if (difference < 0) {
                    clearInterval(interval);
                    if (callback && typeof callback === 'function') callback(container);
                    return;
                } else {
                    var _second = 1000, _minute = _second * 60, _hour = _minute * 60, _day = _hour * 24;
                    var days = Math.floor(difference / _day), hours = Math.floor((difference % _day) / _hour),
                        minutes = Math.floor((difference % _hour) / _minute),
                        seconds = Math.floor((difference % _minute) / _second);
                    days = (String(days).length >= 2) ? days : '0' + days;
                    hours = (String(hours).length >= 2) ? hours : '0' + hours;
                    minutes = (String(minutes).length >= 2) ? minutes : '0' + minutes;
                    seconds = (String(seconds).length >= 2) ? seconds : '0' + seconds;
                    var ref_days = (days === 1) ? 'day' : 'days', ref_hours = (hours === 1) ? 'hour' : 'hours',
                        ref_minutes = (minutes === 1) ? 'minute' : 'minutes',
                        ref_seconds = (seconds === 1) ? 'second' : 'seconds';
                    container.html(`<span>${days}天${hours}时${minutes}分${seconds}秒</span>`)
                }

            }
        }

        var interval = setInterval(countdown, 1000);
        intervalMap[key] = interval;
    };
    $.fn.shutdown = function (key) {
        clearInterval(intervalMap[key]);
    }
})(jQuery);