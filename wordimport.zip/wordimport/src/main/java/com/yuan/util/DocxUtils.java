package com.yuan.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.docx4j.Docx4J;
import org.docx4j.Docx4jProperties;
import org.docx4j.convert.out.HTMLSettings;
import org.docx4j.openpackaging.exceptions.Docx4JException;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;

public class DocxUtils {
    @Autowired
    /**
     * 将docx转换成html
     * @param docx
     * @param html
     * @throws FileNotFoundException
     * @throws Docx4JException
     */
    public static void docx2html(String docx,String html) throws FileNotFoundException, Docx4JException{
        //1.生成的HTML文件需要提前创建好
        File file = new File(html);
        if(!file.exists()){
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        WordprocessingMLPackage wordMLPackage= Docx4J.load(new java.io.File(docx));
        HTMLSettings htmlSettings = Docx4J.createHTMLSettings();
        String imageFilePath=html.substring(0,html.lastIndexOf("/")+1)+"/images";
        htmlSettings.setImageDirPath(imageFilePath);
        htmlSettings.setImageTargetUri( "images");
        htmlSettings.setWmlPackage(wordMLPackage);
        String userCSS = "html, body, div, span,font, h1, h2, h3, h4, h5, h6, p, a, img,  ol, ul, li, table, caption, tbody, tfoot, thead, tr, th, td " +
                "{ margin: 0; padding: 0; border: 0;}" +
                "body {line-height: 1;} ";

        htmlSettings.setUserCSS(userCSS);
        OutputStream os;
        os = new FileOutputStream(html);
        Docx4jProperties.setProperty("docx4j.Convert.Out.HTML.OutputMethodXML", true);
        Docx4J.toHTML(htmlSettings, os, Docx4J.FLAG_EXPORT_PREFER_XSL);
    }
    /**
     * 读取HTML中文字内容和图片信息
     * @param HTMLPath
     * @return
     * @throws IOException
     */
    public static List<String> readHTML(String HTMLPath) throws IOException{
        List<String> allList = new ArrayList<>();
        File input = new File(HTMLPath);
        Document doc = Jsoup.parse(input, "UTF-8", "");
        //jsoup标签选择器，选择读取的标签
        Elements linkstest = doc.select("p.a ");
        //wps和word创建的文件生成的html中的span标签的class属性值不一样
        //所以在解析之前先判断html文件中是否存在class为a0的span标签,有则用之无则改为2
        Elements links=null;
        if(linkstest.isEmpty()){
            links = doc.select("span.2 ,img");
        }else{
            links = doc.select("p.a ,img");
        }
        /*Elements links = doc.select("p,img");*/
        String item = "";
        boolean flag = false;
        for (Element link : links) {
            //读取每个标签的数据可能会将一段话或者一行文字分成多个标签进行存储，
            //后面会根据这里读取的数据的某一种格式进行试题切分，
            //所以这里需要将特殊格式的数据拼接到一起之后再进行存储
            String itemContent = link.text();
            if("【".equals(itemContent)){
                flag = true;
                item = item+itemContent;
            }else{
                if(flag){
                    item = item+itemContent;
                    if(itemContent.contains("】")){
                        allList.add(item);
                        item="";
                        flag = false;
                    }
                }else{
                    allList.add(itemContent);
                }
            }
            if(!"".equals(link.attr("id"))){
                allList.add("&^&"+link.attr("id")+"&^&");
            }
        }
        return allList;
    }
    /**
     * 去除listh中的重复数据
     * @param list
     * @return
     */
    public static List removeDuplicate(List list){
        List listTemp = new ArrayList();
        for(int i=0;i<list.size();i++){
            if(!listTemp.contains(list.get(i))){
                listTemp.add(list.get(i));
            }
        }
        return listTemp;
    }
    /**
     * 获取分隔后的question字符串列表
     * @param list
     * @param typeNameAndCodeMap
     * @return
     */
    public static List<String> getQuestionsStrList(List<String> list, Map<String, Integer> typeNameAndCodeMap){
        List<String> qmsgList = new ArrayList<String>();
        StringBuffer qcontentItem =new StringBuffer();
        int count =0;
        int qNum = 0;
        //划分题目
        Matcher m = null;
        Map<String, Object> tempMap = null;
        String line ="";
        boolean typeFlag=false;
        //存放题型说明
        String typeDesc = "";
        for (int i = 0; i < list.size(); i++) {
            line = list.get(i).toString();
            if(line.indexOf("【单选】")>-1||line.indexOf("【多选】")>-1||line.indexOf("【填空】")>-1||line.indexOf("【判断】")>-1||line.indexOf("【综合】")>-1){
                if(qNum>0){
                    //不是第一题
                    qmsgList.add(qcontentItem.toString());
                }
                qcontentItem = new StringBuffer();
                qcontentItem.append(line);
                qNum++;
            }else {
                qcontentItem.append(line);
            }
            if(i==list.size()-1){
                qmsgList.add(qcontentItem.toString());
            }
        }
        return qmsgList;
    }
    /**
     * 获取字符串中所有的子串的位置
     * @param str
     * @return
     */
    public static String getAllSonstrIndex(String str,String sonStr){
        StringBuffer buffer = new StringBuffer();
        int index = str.indexOf(sonStr);
        while(index!=-1){
            buffer.append(index+",");
            index = str.indexOf(sonStr,index+1);
        }
        String string = buffer.toString();
        if(string.indexOf(",")!=-1){
            string = string.substring(0, string.lastIndexOf(","));
        }
        return string;
    }
    /**
     * 获取图片唯一标识list
     * @param str:总的字符串
     * @return
     */
    public static String getShortStr(String str){
        List<String> resList = new ArrayList<String>();
        String indexsStr = getAllSonstrIndex(str,"&^&");
        String[] indexs = indexsStr.split(",");
        int start = 0;
        int end = 0;
        for (int i = 0; i < indexs.length-1; i=i+2) {
            start=Integer.parseInt(indexs[i]);
            end=Integer.parseInt(indexs[i+1]);
            resList.add(str.substring(start+3,end));
        }
        return resList.get(0);
    }
}
