package com.yuan.util;

import java.io.Serializable;

public class JsonWrite implements Serializable {
    private static final long serialVersionUID = -12912540624848120L;
    private boolean success = false;
    private String msg;
    private Object obj;
    private String lastvalue;
    private String onevalue;

    public String getOnevalue() {
        return onevalue;
    }
    public void setOnevalue(String onevalue) {
        this.onevalue = onevalue;
    }

    public String getLastvalue() {
        return lastvalue;
    }

    public void setLastvalue(String lastvalue) {
        this.lastvalue = lastvalue;
    }
    public String getOthervalue() {
        return othervalue;
    }

    public void setOthervalue(String othervalue) {
        this.othervalue = othervalue;
    }

    private String othervalue;

    public JsonWrite() {

    }
    public JsonWrite(boolean success, String msg) {
        this.success = success;
        this.msg = msg;
    }

    public JsonWrite(boolean success, String msg, Object obj) {
        this.success = success;
        this.msg = msg;
        this.obj = obj;
    }
    public JsonWrite(boolean success, String msg, Object obj, String othervalue) {
        this.success = success;
        this.msg = msg;
        this.obj = obj;
        this.othervalue = othervalue;
    }

    public boolean isSuccess() {
        return success;
    }
    public void setSuccess(boolean success) {
        this.success = success;
    }

    public Object getObj() {
        return obj;
    }

    public void setObj(Object obj) {
        this.obj = obj;
    }
    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}

