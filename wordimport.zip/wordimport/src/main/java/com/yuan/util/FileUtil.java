package com.yuan.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.springframework.web.multipart.MultipartFile;
/**
 * 文件工具类
 *
 */
public final class FileUtil {
    /**
     * 文件保存
     *
     * @param file
     *            文件
     * @param path
     *            文件保存路径
     * @param newName
     *            新文件名
     * @return
     * @throws IOException
     */
    public static String fileUpload(MultipartFile file, String path, String newName) throws IOException {
        if (!file.isEmpty()) {
            String filename = file.getName(); // 得到上传时的文件名
            filename = newName + filename.substring(filename.lastIndexOf("."));
            // 文件保存路径（images/用户编号/head/图片名）
            String dir = path + "/"; // 设定文件保存的目录
            FileUtils.writeByteArrayToFile(new File(dir, filename), file.getBytes());
            return filename;
        } else {
            return null;
        }
    }
    // 获取resources下面URL.properties 值 wyp 2017-6-15
    public static String getfile(String propertiesName, String name) throws IOException {
        ClassLoader classloader = Thread.currentThread().getContextClassLoader();
        InputStream is = classloader.getResourceAsStream(propertiesName);
        Properties properties = new Properties();
        properties.load(is);
        String bath = properties.getProperty(name);
        return bath;
    }
}

