package com.yuan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WordimportApplication {

    public static void main(String[] args) {
        SpringApplication.run(WordimportApplication.class, args);
    }

}
