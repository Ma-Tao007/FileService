package com.yuan.entity;


import java.util.List;
@lombok.Data
public class Data {
    Integer problemType;// (题目类型) 1，单选 2，多选， 3判断， 4 填空， 5 综合
    String diff;//(难度)
    String grade;// 分数
    String problem;// 题干
    List<Option> options;//选项
    String answer; //答案
    String answeranalysis;// 答案解析
    String label;//标签的内容
    byte[] Picture;//二进制的图片
    String picflag;
    List<Data> children;//综合题下的子题,子题分为单选、多选、判断、填空

}
