package com.yuan.entity;

import lombok.Data;

@Data
public class Option {
    String content;// 内容，比如【A】这是A选项
    String Picture;//二进制的图片

}
