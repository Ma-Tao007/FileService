package com.yuan.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class MyMvcConfig implements WebMvcConfigurer {
    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        //标的列表页面
        registry.addViewController("/index.html").setViewName("index");
        registry.addViewController("/").setViewName("index");
        //登录页面
        registry.addViewController("/login").setViewName("login");
        registry.addViewController("/cards").setViewName("cards");
        registry.addViewController("/monitor").setViewName("monitor");
        registry.addViewController("/monitor2").setViewName("monitor2");

    }
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
       
        //第一个方法设置访问路径前缀，第二个方法设置资源路径
        registry.addResourceHandler("/static/**").addResourceLocations("classpath:/static/");
    }
}
