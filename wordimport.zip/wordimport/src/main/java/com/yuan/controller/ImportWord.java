package com.yuan.controller;


import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.ResourceBundle;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.serializer.SimplePropertyPreFilter;
import com.yuan.entity.Data;
import com.yuan.entity.Option;
import com.yuan.util.DocxUtils;
import com.yuan.util.FileUtil;
import com.yuan.util.JsonWrite;
import net.engio.mbassy.subscription.ISubscriptionContextAware;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFPictureData;
import org.opendope.questions.Question;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;
/**
 * 试题word导入controller
 */
@SuppressWarnings("all")
@Controller
@RequestMapping("/word")
public class ImportWord {
    public JsonWrite jsonWrite = new JsonWrite(true, "");


    /**
     * word导入
     *
     * @param upfile
     * @param response
     * @throws Exception
     */
    @RequestMapping("/importWord")
    public void importWord( HttpServletResponse response, HttpServletRequest request) throws Exception {
        File file = new File("E:/zcypack/testtest.docx");
        //File转换成Multipartfile
        InputStream inputStream = new FileInputStream(file);
        MultipartFile multipartFile = new MockMultipartFile(file.getName(), inputStream);
        // 1.将导入的文件上传到本地
        String rootpath = "E:\\zcypack\\";
        String userpath = UUID.randomUUID().toString();
        String newpath = FileUtil.fileUpload(multipartFile, rootpath + userpath, "root");
        request.getSession().setAttribute("wordUUIDFileName", rootpath + userpath);
        request.getSession().setAttribute("wordRootPath", rootpath + userpath + "/" + newpath);
        String imgLocalPath = "E:\\zcypack\\img";
        String imgLoadPath = "http:192.168.1.83:8001/questionimgs/";
        List<Data> questionMsgList = null;
        // 错误提示信息
        String msg = "";
        // 解析word文件
        List<Map<String, Object>> res = null;
        try {
            // 获取word中解析出来的试题
            // 1.将docx转换成HTML
            DocxUtils.docx2html(rootpath + userpath + "/" + newpath, rootpath + userpath + "/" + "root.html");
            // 2.解析HTML，获取question字符串列表
            List<String> questionStringList = DocxUtils.readHTML(rootpath + userpath + "/" + "root.html");
            // 3.解析字符串列表获取question信息列表
            List<String> questionList = DocxUtils.getQuestionsStrList(questionStringList,null);
            // 4.解析上面列表，生成question实体及相关信息列表
            questionMsgList = getQuestions(questionList, request);
            //获取文档中所有图片二进制信息
            Map<String, byte[]> imgsMap = getImgUrl( request);
            // 将图片信息设置到对应的试题中去
            Data data = null;
            for (int i = 0; i < questionMsgList.size(); i++) {
                data = questionMsgList.get(i);
                if(data.getPicture()!=null){
                    data.setPicture(imgsMap.get(data.getPicture()));
                }
            }
        } catch (Exception e) {
            msg = "导入失败，请仔细检查文件中试题格式";
            jsonWrite.setSuccess(false);
            e.printStackTrace();
        }
        if ("".equals(msg)) {
            msg = "导入成功";
            jsonWrite.setSuccess(true);
            // 删除上传的临时文件
            deleteDir(new File((String) request.getSession().getAttribute("wordUUIDFileName")));
        }
        jsonWrite.setMsg(msg);
        writeJson(response, jsonWrite);
    }
    public List<Data> getQuestions(List<String> questionStrList, HttpServletRequest request) throws Exception {
        List<Data> questionList = new ArrayList<Data>();
        //题型类型code值map
        HashMap<String,Integer> map = new HashMap<String,Integer>();
        map.put("【单选】",1);
        map.put("【多选】",2);
        map.put("【判断】",3);
        map.put("【填空】",4);
        map.put("【综合】",5);
        //题型说明
        String typedesc = "";
        //试题字符串
        String qcontent = "";
        //试题实体变量
        Data data =null;
        for (int i = 0;i<questionStrList.size();i++){
            data = new Data();
            qcontent = questionStrList.get(i);
            typedesc = qcontent.substring(0,4);
            //设置题型
            data.setProblemType(map.get(typedesc));
            if(map.get(typedesc)==1){
                //单选
                //解析字符串 将对应内容放入实体
                formatSingle(qcontent,typedesc,data);
                questionList.add(data);
            }
        }
        return questionList;
    }
    public void formatSingle(String qcontent,String typedesc,Data data){
        //去除题型信息
        qcontent = qcontent.substring(qcontent.indexOf("】")+1);
        //截取难度
        String diff  = qcontent.substring(1,qcontent.indexOf("】"));
        data.setDiff(diff);
        //去除难度
        qcontent= qcontent.substring(qcontent.indexOf("】")+1);
        //截取分数
        String grade = qcontent.substring(1,qcontent.indexOf("】"));
        data.setGrade(grade);
        //去除分数
        qcontent= qcontent.substring(qcontent.indexOf("】")+1);
        //截取题干
        String problem = qcontent.substring(0,qcontent.indexOf("【"));
        //判断题目中是否有图片
        String picmsg = "";
        if(problem.indexOf("&^&")>-1){
            //有图片
            picmsg = problem.substring(problem.indexOf("&^&")+3,problem.lastIndexOf("&^&"));
            problem.replace("&^&"+picmsg+"&^&","");
            data.setPicflag(picmsg);
        }
        data.setProblem(problem);
        //截取选项
        List<Option> options = new ArrayList<Option>();
        Option option = new Option();
        String o1 = qcontent.substring(qcontent.indexOf("【A】")+3,qcontent.indexOf("【B】"));
        String o2 = qcontent.substring(qcontent.indexOf("【B】")+3,qcontent.indexOf("【C】"));
        String o3 = qcontent.substring(qcontent.indexOf("【C】")+3,qcontent.indexOf("【D】"));
        String o4 = qcontent.substring(qcontent.indexOf("【D】")+3,qcontent.indexOf("【参考答案】"));
        option.setContent(o1);
        options.add(option);
        option = new Option();
        option.setContent(o2);
        options.add(option);
        option = new Option();
        option.setContent(o3);
        options.add(option);
        option = new Option();
        option.setContent(o4);
        options.add(option);
        //判断选项中有没有图片
        String optionStr = "";
        for (int i = 0; i < options.size(); i++) {
            optionStr = options.get(i).getContent();
            if(optionStr.indexOf("&^&")>-1){
                //有图片
                picmsg = optionStr.substring(optionStr.indexOf("&^&")+3,optionStr.lastIndexOf("&^&"));
                optionStr=optionStr.replace("&^&"+picmsg+"&^&","");
                options.get(i).setPicture(picmsg);
                options.get(i).setContent(optionStr);
            }
        }
        data.setOptions(options);
        //截取参考答案
        String answer = qcontent.substring(qcontent.indexOf("【参考答案】")+6,qcontent.indexOf("【答案解析】"));
        data.setAnswer(answer);
        //截取答案解析
        String answeranalysis = qcontent.substring(qcontent.indexOf("【答案解析】")+6,qcontent.indexOf("【标签"));
        data.setAnsweranalysis(answeranalysis);
        //截取标签
        String label = qcontent.substring(qcontent.indexOf("【标签")+3,qcontent.length()-2);
        data.setLabel(label);
    }
    public static Map<String, byte[]> getImgUrl( HttpServletRequest request) throws Exception {
        String imgLocalPath = "E:\\zcypack\\img";
        String imgLoadPath = "http:192.168.1.83:8001/questionimgs/";
        String Indexdocx = request.getSession().getAttribute("wordRootPath").toString();
        // 读取总文件
        InputStream in = new FileInputStream(Indexdocx);
        XWPFDocument xwpfDocumentIndex = new XWPFDocument(in);
        in.close();
        List<XWPFPictureData> list = xwpfDocumentIndex.getAllPackagePictures();
        // 需要获取数据的图片名称
        String paraPicName = "";
        // 总文档中的图片名称
        String pictureName = "";
        // 上传到图片服务器之后的图片名称
        // 图片索引rId1/rId2/rId3..
        String id = "";
        String uuidName = "";
        String endName = "";
        byte[] bd = null;
        // 方法返回的List包含，题目序号，上传之后图片名称
        List<Map<String, Object>> resMapList = new ArrayList<Map<String, Object>>();
        Map<String, byte[]> imgUploadNameMap = new HashMap<String, byte[]>();
        byte[] itemArr = null;
        //遍历文档中的所有图片信息
        for (XWPFPictureData xwpfPictureData : list) {
            uuidName = UUID.randomUUID().toString();
            id = xwpfPictureData.getParent().getRelationId(xwpfPictureData);
            pictureName = xwpfPictureData.getFileName();
            endName = pictureName.substring(pictureName.lastIndexOf("."));
            bd = xwpfPictureData.getData();
            FileOutputStream fos = new FileOutputStream(new File(imgLocalPath + uuidName + endName));
            fos.write(bd);
            fos.flush();
            fos.close();
            itemArr = getImgArry(imgLocalPath + uuidName + endName);
            imgUploadNameMap.put(id, itemArr);
        }
        // 遍历参数
//        List<String> tempPicNameList = null;
//        String tempValue = "";
//        String tempName = "";
//        Map<String, String> itemMap = null;
//        for (Map<String, Object> map : imgMsgList) {
//            itemMap = new HashMap<String, String>();
//            tempPicNameList = (List<String>) map.get("imgIndexs");
//            for (String string : tempPicNameList) {
//                tempValue = imgUploadNameMap.get(string);
//                if (tempValue != null) {
//                    itemMap.put(string, tempValue);
//                } else {
//                    itemMap.put(string, "");
//                }
//                map.put("imgIndexs", itemMap);
//            }
//            resMapList.add(map);
//        }
        return imgUploadNameMap;
    }
    /**
     * 递归删除目录下的所有文件及子目录下所有文件
     *
     * @param dir 将要删除的文件目录
     * @return boolean Returns "true" if all deletions were successful. If a
     * deletion fails, the method stops attempting to delete and returns
     * "false".
     */
    private boolean deleteDir(File dir) {
        if (dir.isDirectory()) {
            String[] children = dir.list();
            // 递归删除目录中的子目录下
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
        }
        // 目录此时为空，可以删除
        return dir.delete();
    }
    /**
     * 输出HTML脚本
     */
    public void writeJson(HttpServletResponse response, Object obj) {
        this.writeJson(response, obj, "utf-8");
    }
    protected void writeJson(HttpServletResponse response, Object obj, String charset) {
        String json = JSON.toJSONString(obj, SerializerFeature.DisableCircularReferenceDetect);
        response.setContentType("text/html;charset=" + charset);
        response.setDateHeader("Expires", -10);
        PrintWriter out = null;
        try {
            out = response.getWriter();
            out.println(json);
            out.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (out != null) {
                out.close();
            }
        }
    }
    /**
     * 用字节流获取图片，把字节数组用ByteArrayOutputStream 写到 bao里面去,，可以返回一个字节数组
     * @param path
     * @return
     */
    public static byte[] getImgArry(String path){
        InputStream inImg=null;
        ByteArrayOutputStream bao=new ByteArrayOutputStream();
        try {
            inImg=new FileInputStream(path);
            byte [] b=new byte[1024];
            int len=-1;
            //将图片的所有字节通过数组b读取出来在写到bao里面去
            while((len=inImg.read(b))!=-1) {
                bao.write(b, 0, len);
            }
            //返回bao字节数组
            return bao.toByteArray();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                bao.close();
                inImg.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return null;

    }
}
