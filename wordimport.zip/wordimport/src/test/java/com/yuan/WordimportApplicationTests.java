package com.yuan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WordimportApplicationTests {

    @Test
    void contextLoads() {
    }

}
